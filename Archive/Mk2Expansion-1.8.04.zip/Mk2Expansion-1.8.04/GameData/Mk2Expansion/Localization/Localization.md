--Mk2 Expansion Localization--

If you want to help translate M2X, it would be a great help.

--How to translate--

Localization files are easy to make. Create a copy of the Mk2Expansion/Localization/en_us.cfg file and rename it according to the language being translated:
* "es-es.cfg" for Spanish
* "es-mx.cfg" for Mexican Spanish
* "ja.cfg" for Japanese
* "ru.cfg" for Russian
* "zh-cn.cfg" for Simplified Chinese

  



